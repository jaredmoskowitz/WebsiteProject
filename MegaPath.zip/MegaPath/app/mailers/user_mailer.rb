class UserMailer < ActionMailer::Base
  default from: "megapathmapping@gmail.com"     #this is an email that I used for a different project during my internship.
                                                #however I figured that it could be used here. Note that the gmail server limits to 100 emails
                                                #per account per day so after testing you obviously need to be using a different server.
  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.send_password.subject
  #
  #This action sends the user an auto-generated password to the email address inputted on 'places/index'
  def send_password(user, password)
    @password = password
    @address = user
    @sites = ""
    Place.find_all_by_user_id(User.find_by_email(@address).id).each do |site|                #find_all_by method needs to be changed
      @sites += "#{site.name} @ #{site.address} - #{site.phone_number}              \n"      #to where method
    end
    mail(to: @address, subject: 'Your new Mega Path Site Site password' )
  end


  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.spam.subject
  #
  def spam
    @greeting = "Hi"

    mail to: "to@example.org"
  end
end
