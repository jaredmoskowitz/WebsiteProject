class PurchasedServicesController < ApplicationController
  #Controller for PurchasedService

  layout "colorbox"
  before_action :set_purchased_service, only: [:show, :edit, :update, :destroy]

  # GET /purchased_services
  # GET /purchased_services.json
  def index
    @purchased_services = PurchasedService.all
  end

  # GET /purchased_services/1
  # GET /purchased_services/1.json
  def show
  end

  # GET /purchased_services/new
  def new
    @purchased_service = PurchasedService.new
  end

  # GET /purchased_services/1/edit
  def edit
  end

  # POST /purchased_services
  # POST /purchased_services.json
  def create
    @purchased_service = PurchasedService.new(purchased_service_params)

    respond_to do |format|
      if @purchased_service.save
        format.html { redirect_to @purchased_service, notice: 'Purchased service was successfully created.' }
        format.json { render action: 'show', status: :created, location: @purchased_service }
      else
        format.html { render action: 'new' }
        format.json { render json: @purchased_service.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /purchased_services/1
  # PATCH/PUT /purchased_services/1.json
  def update
    respond_to do |format|
      if @purchased_service.update(purchased_service_params)
        format.html { redirect_to @purchased_service, notice: 'Purchased service was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @purchased_service.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /purchased_services/1
  # DELETE /purchased_services/1.json
  def destroy
    @purchased_service.destroy
    respond_to do |format|
      format.html { redirect_to purchased_services_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_purchased_service
      @purchased_service = PurchasedService.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def purchased_service_params
      params.require(:purchased_service).permit(:inservice_date, :service_type, :service, :service_identification, :service_status, :last_live, :order_mrc, :order_nrc)
    end
end
