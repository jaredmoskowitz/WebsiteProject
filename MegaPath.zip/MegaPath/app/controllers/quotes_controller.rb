class QuotesController < ApplicationController
  #controller for Quote

  layout "colorbox"
  skip_before_filter  :verify_authenticity_token
  before_action :set_quote, only: [:show, :edit, :update, :destroy]  #takes in a place id instead of quote id

  # GET /quotes
  # GET /quotes.json
  def index
    @quotes = Quote.all
  end

  # GET /quotes/1
  # GET /quotes/1.json
  #
  #Sets the current quote's :open_quote_id to open_quote for current place if save button committed
  #otherwise sets :order_history_id to current place
  #
  #redirects to either 'open_quotes/[curent place id]'
  #or to 'order_history/[current place id]'
  #
  #TODO fix bug where clicking on Open Quote tab or Order History tab before quote created throws an error
  def show
    if params[:commit] == 'save'
      @quote.update_attributes(:open_quote_id => Place.find(@quote.place_id).open_quotes.first.id, :details => params[:text], :name => Faker::Name.name, :quote_date => Time.now.asctime )       #right now the name of quote created is generated name and date is date created
      redirect_to "/open_quotes/#{Place.find(@quote.place_id).open_quotes.first.id}"
    elsif params[:commit] == 'submit'
      @quote.update_attributes(:order_history_id => Place.find(@quote.place_id).order_histories.first.id, :details => params[:text], :name => Faker::Name.name, :quote_date => Time.now.asctime )
      redirect_to "/order_histories/#{Place.find(@quote.place_id).order_histories.first.id}"
    end
  end

  # GET /quotes/new
  def new
    @quote = Quote.new
  end

  # GET /quotes/1/edit
  def edit
  end

  # POST /quotes1
  # POST /quotes.json
  #
  #I think this is needless code
  def create
    if params[:commit] == 'save'
      @quote.update_attributes(:open_quote_id => Place.find(@quote.place_id).open_quotes.first.id, :details => params[:text], :name => Time.now.to_s)                                                                                                                                #right now the name of quote created defaults to date and time create at
    else
      @quote.update_attributes(:order_history_id => Place.find(@quote.place_id).order_histories.first.id, :details => params[:text], :name => Time.now.to_s)
    end
  end

  # PATCH/PUT /quotes/1
  # PATCH/PUT /quotes/1.json
  def update
    respond_to do |format|
      if @quote.update(quote_params)
        format.html { redirect_to @quote, notice: 'Quote was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @quote.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /quotes/1
  # DELETE /quotes/1.json
  def destroy
    @quote.destroy
    respond_to do |format|
      format.html { redirect_to quotes_url }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_quote
    @quote = Quote.new(:place_id => params[:id])
  end


  # Never trust parameters from the scary internet, only allow the white list through.
  def quote_params
    params.require(:quote).permit(:id, :name, :category, :service, :description, :estimated_delivery, :current_status, :total_mrc, :total_nrc, :details)
  end
end
