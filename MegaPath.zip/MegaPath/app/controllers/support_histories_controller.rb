class SupportHistoriesController < ApplicationController
  #Controller for SupportHistory

  layout "colorbox"
  before_action :set_support_history, only: [:show, :edit, :update, :destroy]
  before_action :set_support_histories, only: [:show]

  # GET /support_histories
  # GET /support_histories.json
  def index
    @support_histories = SupportHistory.all
  end

  # GET /support_histories/1
  # GET /support_histories/1.json
  def show
  end

  # GET /support_histories/new
  def new
    @support_history = SupportHistory.new
  end

  # GET /support_histories/1/edit
  def edit
  end

  # POST /support_histories
  # POST /support_histories.json
  def create
    @support_history = SupportHistory.new(support_history_params)

    respond_to do |format|
      if @support_history.save
        format.html { redirect_to @support_history, notice: 'Support history was successfully created.' }
        format.json { render action: 'show', status: :created, location: @support_history }
      else
        format.html { render action: 'new' }
        format.json { render json: @support_history.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /support_histories/1
  # PATCH/PUT /support_histories/1.json
  def update
    respond_to do |format|
      if @support_history.update(support_history_params)
        format.html { redirect_to @support_history, notice: 'Support history was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @support_history.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /support_histories/1
  # DELETE /support_histories/1.json
  def destroy
    @support_history.destroy
    respond_to do |format|
      format.html { redirect_to support_histories_url }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_support_history
    @support_history = SupportHistory.find(params[:id])
  end

  def set_support_histories
    @support_histories = Place.find(SupportHistory.find(params[:id]).place_id).support_histories
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def support_history_params
    params.require(:support_history).permit(:reported_on, :service_type, :service, :service_identification, :ticket_status, :description, :last_status_date)
  end
end
