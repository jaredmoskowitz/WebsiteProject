class PageController < ApplicationController
  #This is the controller for the main home page

  #GET /page
  def index
  end

  #POST /page/1
  def show
  end

  #GET /page/new
  def new
  end

  #this action is called when a user presses the submit button at '/page/index'
  #The params :place, :phone, and :title are assigned to the attr for a Place object
  #:address, :phone_number, and :title, respectively
  def create
    @location = Place.create(:address => params[:place], :phone_number  => params[:phone], :name  => params[:title], :status => "not_purchased", :user_id => current_or_guest_user.id)
    Quote.create(:place_id => @location.id)
    OpenQuote.create(:place_id => @location.id)
    OrderHistory.create(:place_id => @location.id)
    PurchasedService.create(:place_id => @location.id)
    SupportHistory.create(:place_id => @location.id)
    BillingInfo.create(:place_id => @location.id)
    respond_to do |format|
      if @location.save
        format.html { redirect_to places_path}
        format.json { render action: 'index', status: :created, location: places_path }
      else
        format.html { render action: 'new' }
        format.json { render json: @location.errors, status: :unprocessable_entity }
      end
    end
  end

  private
# Never trust parameters from the scary internet, only allow the white list through.
  def page_params
    params.require(:place).permit(:name, :address, :longitude, :latitude, :gmaps, :status, :phone_number, :email_address, :user_id)
  end
end

