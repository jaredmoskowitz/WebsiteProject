class OpenQuotesController < ApplicationController
  layout"colorbox"
  before_action :set_open_quote, only: [:show, :edit, :update, :destroy]

  # GET /open_quotes
  # GET /open_quotes.json
  def index
    @open_quotes = OpenQuote.all
  end

  # GET /open_quotes/1
  # GET /open_quotes/1.json
  def show
  end

  # GET /open_quotes/new
  def new
    @open_quote = OpenQuote.new
  end

  # GET /open_quotes/1/edit
  def edit
  end

  # POST /open_quotes
  # POST /open_quotes.json
  def create
    @open_quote = OpenQuote.new(open_quote_params)

    respond_to do |format|
      if @open_quote.save
        format.html { redirect_to @open_quote, notice: 'Open quote was successfully created.' }
        format.json { render action: 'show', status: :created, location: @open_quote }
      else
        format.html { render action: 'new' }
        format.json { render json: @open_quote.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /open_quotes/1
  # PATCH/PUT /open_quotes/1.json
  def update
    respond_to do |format|
      if @open_quote.update(open_quote_params)
        format.html { redirect_to @open_quote, notice: 'Open quote was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @open_quote.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /open_quotes/1
  # DELETE /open_quotes/1.json
  def destroy
    @open_quote.destroy
    respond_to do |format|
      format.html { redirect_to open_quotes_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_open_quote
      @open_quote = OpenQuote.find(params[:id])
    end

    def set_quote
      @quote = OpenQuote.find(params[:id]).first
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def open_quote_params
      params.require(:open_quote).permit(:quote_date, :quote_name, :valid_until, :quote_status, :order_mrc, :order_nrc)
    end
end
