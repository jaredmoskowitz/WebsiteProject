class PlacesController < ApplicationController
  #Controller for the map page. A guest account is automatically created to
  #store site locations to if no user is signed in. Once an email address is given
  #the information in guest user is passed off to a new registered user and a password
  # for the registered user along with recently added sites is sent to the email address given.
  #NOTE I have not written the code yet to destory the guest account after user account is created.
  #refer to the 'logging_in' action in 'application_controller' for help on doing this

  before_action :set_place, only: [:show, :edit, :update, :destroy]
  before_action :create_guest
  #before_filter :authentice_user!, :except => [:bundles, :index] (developer's reference for later)


  #GET /emailpassword
  #
  #Calls the 'send_password method in the Mailer with given email and password parameters'
  def email_password(mail, password)
    UserMailer.send_password(mail, password).deliver
  end

  # GET /places
  # GET /places.json
  def index
    if current_user
      @places = current_user.places
      @json = current_user.places.to_gmaps4rails
    else
      @places = guest_user.places
      @json = guest_user.places.to_gmaps4rails
    end
  end

  # GET /places/1
  # GET /places/1.json
  def show
    respond_to do |format|
      format.html # bundlesles.html.erb
      format.json { render json: @place }
    end
  end

  # GET /places/new
  def new
    @place = Place.new
    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @place }
    end
  end

  # GET /places/1/edit
  def edit
  end

  # POST /places
  # POST /places.json
  #
  ##this action is called when a user presses the 'Add Me!' button at '/places/index'
  #The params :location, :phone, and :title are assigned to the attr for a Place object
  #:address, :phone_number, and :title, respectively
  #
  #
  #The corresponding information for the pages displayed in a colorbox for each locations
  #are created when the place is created.
  #
  #
  #If the email form is not left empty then this action will call the 'createUser action'
  def create
    @place = Place.create(:address => params[:location], :phone_number  => params[:phone], :name  => params[:title], :status => "not_purchased", :user_id => current_or_guest_user.id, :email_address => params[:email_ad])
    Quote.create(:place_id => @place.id)
    OpenQuote.create(:place_id => @place.id)
    OrderHistory.create(:place_id => @place.id)
    PurchasedService.create(:place_id => @place.id)
    SupportHistory.create(:place_id => @place.id)
    BillingInfo.create(:place_id => @place.id)
    respond_to do |format|
      if @place.save
        format.html { redirect_to places_path}
        format.json { render action: 'index', status: :created, location: places_path }
      else
        format.html { render action: 'new' }
        format.json { render json: @place.errors, status: :unprocessable_entity }
      end
      if !params[:email_ad].nil?             #calls the createUser action if :email_ad param is not nil
        @email = params[:email_ad]           #TODO create label for the email submit button instead and check to see
        self.createUser                      #if that button was clicked. It seems like much better code. I wrote this early
      end                                    #on and did not have time to fix when I saw this poor code when documenting at
    end                                      #at the end

  end




  #PUT /places/createUser
  #checks to see whether a given email is already in the system
  #otherwise the app will create a new user and send email to the given email address
  #by calling the 'email_password' action
  def createUser
    if current_or_guest_user == User.find_by_email(@email)
      user_ident = User.find_by_email(@email).id
      current_or_guest_user.places.each do |place|
        Place.update(place.id, :user_id => user_ident)
      end
    else
      pw = Password.pronounceable
      new_user = User.create(:email => @email, :password => pw)
      ref = new_user.id
      guest_user.places.each do |place|
        Place.update(place.id, :user_id => ref)
      end
      self.email_password(new_user.email, pw)
    end
    @place.destroy       #this was a fix to a bug where a blank place object was created after submitting email
  end                    #TODO create assign id to each button so that the params recieved from each button can
  #be checked to see which one was clicked.
  #I created this early on before I knew how to use multiple buttons the proper way. Sorry.






  # PATCH/PUT /places/1
  # PATCH/PUT /places/1.json
  def update
    respond_to do |format|
      if @place.update(params[:place])
        format.html { redirect_to @place, notice: 'Place was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @place.errors, status: :unprocessable_entity }
      end
    end
  end

# DELETE /places/1
# DELETE /places/1.json
  def destroy
    @place = Place.find(params[:id])
    @place.destroy
    respond_to do |format|
      format.html { redirect_to places_url }
      format.json { head :no_content }
    end
  end


  #POST '/places/import'
  #takes given file of locations and called by
  #Place.rb to process
  def import
    if current_or_guest_user
      Place.import(params[:file], current_or_guest_user)
    else
      Place.import(params[:file], create_guest_user)
    end
    redirect_to places_path, notice: "Site(s) imported."
  end

  #called as a before_action to create guest when loading any '/places'
  #view if there is no user signed in
  def create_guest
    if current_or_guest_user
      return
    else
      create_guest_user
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_place
    @place = Place.find(params[:id])
  end

# Never trust parameters from the scary internet, only allow the white list through.
  def place_params
    params.require(:place).permit(:name, :address, :longitude, :latitude, :gmaps, :status, :phone_number, :email_address, :user_id)
  end
end
