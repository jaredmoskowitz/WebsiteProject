class ProductsController < ApplicationController
  #Controller for Product

  layout "colorbox"
  skip_before_filter  :verify_authenticity_token
  before_action :set_product, only: [:show, :edit, :update, :destroy]

  # GET /products
  # GET /products.json
  def index
    @products = Product.all
  end

  # GET /products/1
  # GET /products/1.json
  def show
  end

  # GET /products/new
  def new
    @product = Product.create()
  end

  # GET /products/1/edit
  def edit
  end

  # POST /products/add/1/1
  #
  #This is called using AJAX in /view/quotes/(:id)
  #to add product to a given quote for a given place
  def add
    ser = ProductCatalog.find(params[:service_id])
    quo = Quote.find(params[:quote_id])
    Product.create(:category => ser.category, :service => ser.service, :description => ser.description, :mrc_term1 => ser.mrc_term1, :nrc_term1 => ser.nrc_term1, :product_catalog_id => ser.id, :quote_id => quo.id)
  end

  # POST /products
  # POST /products.json
  def create
    @product = Product.new(product_params)

    respond_to do |format|
      if @product.save
        format.html { redirect_to @product, notice: 'Product was successfully created.' }
        format.json { render action: 'show', status: :created, location: @product }
      else
        format.html { render action: 'new' }
        format.json { render json: @product.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /products/1
  # PATCH/PUT /products/1.json
  def update
    respond_to do |format|
      if @product.update(product_params)
        format.html { redirect_to @product, notice: 'Product was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @product.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /products/1
  # DELETE /products/1.json
  def destroy
    @product.destroy
    respond_to do |format|
      format.html { redirect_to products_url }
      format.json { head :no_content }
    end
  end

  #DELETE /products/delete/1/1
  #
  #This is called using AJAX in /view/quotes/(:id)
  #to delete a product from a given quote for a given place
  def delete
    Product.find_all_by_quote_id(params[:quote_id]).each do |product|
      if product.product_catalog_id == params[:service_id]
        product.destroy
      end
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_product
    @product = Product.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def product_params
    params.require(:product).permit(:product_identification, :product, :service, :mrc_term1, :mrc_term2, :mrc_term3, :nrc_term1, :nrc_term2, :nrc_term3, :description, :row_index)
  end
end
