class ProductCatalogsController < ApplicationController
  #Controller for ProductCatalog

  layout  "colorbox"
  skip_before_filter  :verify_authenticity_token #this may need to be changed but it helped me get AJAX for 'quotes/#' working

  # GET /product_catalogs
  # GET /product_catalogs.json
  def index
    @product_catalogs = ProductCatalog.all
  end

  #GET /product_catalogs/access
  #
  #Creates instance var of only the access products from ProductCatalog
  def access
    @access_products = ProductCatalog.where(category: "Access")
  end

  #GET /product_catalogs/bundles
  #
  #Creates instance var of only the pre-packaged bundle products from ProductCatalog
  def bundles
    @bundle_products = ProductCatalog.where(category: "Pre-packaged Bundle")
  end

  #GET /product_catalogs/voice
  #
  #Creates instance var of only the voice products from ProductCatalog
  def voice
    @voice_products = ProductCatalog.where(category: "Voice")
  end

  #GET /product_catalogs/security
  #
  #Creates instance var of only the security products from ProductCatalog
  def security
    @security_products = ProductCatalog.where(category: "Security")
  end



  # GET /product_catalogs/new
  def new
    @product_catalog = ProductCatalog.new
  end

  # GET /product_catalogs/1/edit
  def edit
  end

  # POST /product_catalogs
  # POST /product_catalogs.json
  def create
    @product_catalog = ProductCatalog.new(product_catalog_params)

    respond_to do |format|
      if @product_catalog.save
        format.html { redirect_to @product_catalog, notice: 'Product catalog was successfully created.' }
        format.json { render action: 'bundles', status: :created, location: @product_catalog }
      else
        format.html { render action: 'new' }
        format.json { render json: @product_catalog.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /product_catalogs/1
  # PATCH/PUT /product_catalogs/1.json
  def update
    respond_to do |format|
      if @product_catalog.update(product_catalog_params)
        format.html { redirect_to @product_catalog, notice: 'Product catalog was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @product_catalog.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /product_catalogs/1
  # DELETE /product_catalogs/1.json
  def destroy
    @product_catalog.destroy
    respond_to do |format|
      format.html { redirect_to product_catalogs_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_product_catalog
      @product_catalog = ProductCatalog.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def product_catalog_params
      params.require(:product_catalog).permit(:id, :product_identification, :category, :service, :mrc_term1, :mrc_term2, :mrc_term3, :nrc_term1, :nrc_term2, :nrc_term3, :description)
    end
end
