class Place < ActiveRecord::Base

  belongs_to :user
  has_many :quotes
  has_many :open_quotes          #change to has_one for cleanliness and change plural to singular whenever called
  has_many :order_histories       #change to has_one for cleanliness and change plural to singular whenever called
  has_many :purchased_services    #change to has_one for cleanliness and change plural to singular whenever called
  has_many :support_histories
  has_many :billing_infos
  attr_accessible :name, :latitude, :longitude, :address, :gmaps, :status, :phone_number, :email_address, :validated, :user_id
  acts_as_gmappable :process_geocoding => false
  geocoded_by :address   # can also be an IP address
                         #validates_presence_of :address, :name
                         #validates_uniqueness_of :email_address
  after_validation :geocode          # auto-fetch coordinates


  #this tells gmaps4rails where to get geocodable location although I used geocode instead to
  #do the geocoding I am hesitant to delete this method
  def gmaps4rails_address
    address
  end

  #info window helper method for marker that displays name, address, and phone number
  #and provides a link to edit page
  #
  #the original plan was to have a validation link in the window and then when marker is validated next time
  #a colorbox will automatically pop-up, but I could not figure this out. Look at the google maps API
  def info_window_helper
    unless validated
      "<h5>#{self.name} @ #{self.address} - #{self.phone_number}</h5><a href=\"/places/#{self.id}/edit\">Edit site</a>" #TODO edit link brings up edit page in colorbox
    else
      "Possibly a link to display if valid or somehow have popup window come up from this"
    end

  end

  #method used to get infowindow content for marker
  def gmaps4rails_infowindow
    info_window_helper
  end


  #Display different color pin based on status of place.
  #as of right now place objects :status always declared as "not_purchased" whenver instantiated
  def gmaps4rails_marker_picture
    if "processed" == status
      {

          "picture" => "/assets/pin_processed.png",
          "width" =>  "50",
          "height" => "50"
      }
    elsif "processing"  == status
      {

          "picture" => "/assets/pin_processing.png",
          "width" =>  "50",
          "height" => "50"
      }
    elsif "not_purchased" == status
      {

          "picture" => "/assets/pin_not_purchased.png",
          "width" =>  "50",
          "height" => "50"
      }
    else
      {
          "picture" => "/assets/pin_unavailable.png",
          "width" =>  "50",
          "height" => "50"
      }
    end
  end

  #Imports locations from given file and
  #create place objects from that data
  def self.import(file, user)
    spreadsheet = open_spreadsheet(file)
    header = spreadsheet.row(1)
    (2..spreadsheet.last_row).each do |i|
      row = Hash[[header, spreadsheet.row(i)].transpose]
      p = Place.create(row)
      p.update(:status => "not_purchased", :user_id => user.id)
      p.save!
      Quote.create(:place_id => p.id)
      OpenQuote.create(:place_id => p.id)
      OrderHistory.create(:place_id => p.id)
      PurchasedService.create(:place_id => p.id)
      SupportHistory.create(:place_id => p.id)
      BillingInfo.create(:place_id => p.id)
    end
  end


  # helper method for import that handles different file types
  #roo gem used for this
  def self.open_spreadsheet(file)
    case File.extname(file.original_filename)
      when ".csv" then Roo::Csv.new(file.path, nil, :ignore)
      when ".xls" then Roo::Excel.new(file.path, nil, :ignore)
      when ".xlsx" then Roo::Excelx.new(file.path, nil, :ignore)
      else raise "Unknown file type: #{file.original_filename}"
    end
  end

end
