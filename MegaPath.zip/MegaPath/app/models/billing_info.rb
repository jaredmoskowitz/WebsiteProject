class BillingInfo < ActiveRecord::Base
  belongs_to :place
  attr_protected
end
