
class ProductCatalog < ActiveRecord::Base
  has_many :products
  attr_protected
end
