class SupportHistory < ActiveRecord::Base
  belongs_to :place
  attr_protected
end
