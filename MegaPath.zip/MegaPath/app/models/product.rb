class Product < ActiveRecord::Base
  belongs_to :product_catalog
  belongs_to :quote
  attr_protected
end
