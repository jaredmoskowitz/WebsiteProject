class PurchasedService < ActiveRecord::Base
  belongs_to :place
  has_many :quotes
  attr_protected
end
