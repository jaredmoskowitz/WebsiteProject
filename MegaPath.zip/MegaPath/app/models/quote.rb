class Quote < ActiveRecord::Base
  has_many :products
  belongs_to :place
  belongs_to :open_quote
  belongs_to :order_history
  belongs_to :purchased_service
  attr_protected
end
