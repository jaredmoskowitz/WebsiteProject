module OpenQuotesHelper
end
