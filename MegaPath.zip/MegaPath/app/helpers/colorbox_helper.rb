module ColorboxHelper
end
