
<map version="0.9.0">
    <node TEXT="Mind Map">
        <node ID="BF34A1D9-1E1C-405C-B827-84A4D62EB7E3" TEXT="Admin" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="0291C0ED-C766-477E-BC52-AE7F19B24BD0" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
        </node>
        <node ID="BB1D7466-A3DA-4FA9-ADA6-636890789F6A" TEXT="Agent" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="026B930B-93D5-4B78-BFC2-31D510694965" TEXT="admin_id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
                <arrowlink DESTINATION="0291C0ED-C766-477E-BC52-AE7F19B24BD0" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="96791008-35A8-4AD2-B900-F05D5A5F407D" TEXT="name: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="94E091CB-1FF3-465C-A814-BCB30A732EA8" TEXT="email: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="66D3CAA4-3B20-4C52-8D15-AA9B46CA0944" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
        </node>
        <node ID="77BD292D-94BE-4D14-8E13-4B9DDB5894D1" TEXT="Partner" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="C0D67408-9372-4696-BA4C-ACE7A231B917" TEXT="admin_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
                <arrowlink DESTINATION="0291C0ED-C766-477E-BC52-AE7F19B24BD0" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="1ECD0873-8BC8-4B03-AF59-4A404C30ECC2" TEXT="email: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="3B1C1F55-DB10-4FA7-B98E-FCBFA30E7F4E" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="AA384008-1D1E-41A6-BC9A-2EF914D6A2BB" TEXT="password: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="ECECFE7E-40B1-4003-9165-262769F7FEE3" TEXT="name: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
        </node>
        <node ID="BF0D12C9-DA47-4F4D-8001-5EF9B79A5C6A" TEXT="Purchased (Services)" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="A661CD01-D287-4366-9088-E85C384CEEC8" TEXT="order_mrc: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="FE72A28A-034B-4A3B-9CEB-8A60C9AD098F" TEXT="service_identification: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="5FE906FF-8338-4FEA-9A5F-F979BE112D9D" TEXT="service_type: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="FB30317E-2FB3-4EFF-BF95-20B035342E2C" TEXT="service: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="F8FC6CA0-F319-4A4E-B591-7533FB2437DA" TEXT="service_status: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
            <node ID="92484690-1057-40EE-87F5-FE7E06E93EB0" TEXT="last_live: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="BF151D29-4DCD-4696-AE2E-A0D0CEE60AB9" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="9AC7CAC6-EE30-4CF6-9AC1-C376C4DC6067" TEXT="place_id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
                <arrowlink DESTINATION="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="F7618C83-F308-46CF-BB3F-A38C6BB86CE3" TEXT="inservice_date: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="8446DD95-EE42-4D09-87A9-B961E0816BC9" TEXT="order_nrc: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
        </node>
        <node ID="770AA89A-B921-4A8D-9AE8-D082B3830452" TEXT="User" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="54023E91-3824-4559-92B9-C89A0370F962" TEXT="admin_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
                <arrowlink DESTINATION="0291C0ED-C766-477E-BC52-AE7F19B24BD0" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="E334AB69-D5CA-4C7E-BBD9-6DB215061BE3" TEXT="partner_id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
                <arrowlink DESTINATION="3B1C1F55-DB10-4FA7-B98E-FCBFA30E7F4E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="8F8F0B48-577C-41E1-AF5D-E538E1D7E32C" TEXT="agent_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
                <arrowlink DESTINATION="66D3CAA4-3B20-4C52-8D15-AA9B46CA0944" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="BE373EA8-4F67-4CDA-B7B1-A7D77FD4FC38" TEXT="[encrypted] password: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="1F8DC495-B986-422E-9436-7706EF8D73B4" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="502E0B07-0C92-4514-8C06-4C061C8180E0" TEXT="email: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="C65F386D-594F-414E-9D15-96D11332DE41" TEXT="name: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
        </node>
        <node ID="5A1E7BFB-899E-457E-847C-47F92593CFEE" TEXT="Support (History)" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="98BD8AF0-51CA-4D87-A54B-176759B79EDE" TEXT="service_type: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="458C96F0-6C7B-4529-BDB5-B7B34E98F680" TEXT="reported_on: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="B5E9D5F2-65F6-484B-BD4C-9606279C0973" TEXT="ticket_status: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="21A3F9C6-756C-4BCD-9C37-2916B147008A" TEXT="service_identification: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="AB490E01-C96F-40F4-B4F5-E10B5C5EE7CD" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="9469A8D4-7393-4939-B982-058DC2A64128" TEXT="service: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="00420AE0-56D1-4521-81A1-B99C03EBB04D" TEXT="place_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
                <arrowlink DESTINATION="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="D6899676-A280-4A91-8F61-745BC197B3B8" TEXT="last_status_date: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="197EF6A3-328D-40B3-9357-54155C8E3E7B" TEXT="description: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
        </node>
        <node ID="7A1B7672-F4CB-40CA-A94E-FF31A234DC74" TEXT="Place" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="AAADD7DD-1029-465D-BAED-558A61E481F3" TEXT="latitude: float" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="C0B806B0-7AC9-4D7C-A3D6-62457E8E1156" TEXT="longitude: float" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="3DC1FE3C-9B37-4F4A-87F5-1029F14F49FC" TEXT="email_address: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="36B57B14-C572-434C-AF4F-31343E27367A" TEXT="phone_number: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="50ACE94E-3989-4C75-9C90-46ECB482D415" TEXT="status: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="8C6FCA9D-BF77-4455-8DAE-9AAE38CB7A1E" TEXT="user_id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
                <arrowlink DESTINATION="770AA89A-B921-4A8D-9AE8-D082B3830452" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="402F9F9A-7AB4-445F-AAA6-9DC4939CD122" TEXT="name: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="19B01F83-9100-444C-8067-12C508524DD5" TEXT="address: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="A624DD1C-A486-4B15-B5A3-C67217674E8E" TEXT="validated: boolean" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
        </node>
        <node ID="00C5259B-2E0A-4045-8EEA-2C976463168F" TEXT="ProductCatalog" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="C51CE299-3262-42D2-9ABD-E4155859DF4A" TEXT="nrc_term1: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="B5FB1B1A-605F-4E6C-A88A-88F1825DC904" TEXT="nrc_term3: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="FE79D39C-D30C-4BF8-9276-6A4CC3CD4155" TEXT="nrc_term2: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="83D62DC4-646B-432D-B76B-5FB3602DEB48" TEXT="category: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="2B084C5A-C602-43EA-9B95-78FF1CA74775" TEXT="mrc_term1: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="023AC9C4-5534-4EB7-9776-AFE241B8DD12" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="AC75FCFB-5113-4720-83CF-29259B6F36E7" TEXT="mrc_term2: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="9368F2BC-C512-4683-BA2C-9AACE318DB80" TEXT="description: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="739F8B62-4585-443E-B611-8A3B8AB056F4" TEXT="mrc_term3: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="FABB344D-3349-4FF3-B232-9DB73D1AF435" TEXT="service: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
        </node>
        <node ID="6284A06C-09F5-4C85-A382-63D3A65FFC1C" TEXT="Quote" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="1342DC7C-B164-4EAC-AF75-36A00D977B1E" TEXT="order_type: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="50551560-170E-4DDF-A506-1CAC9C08FEEC" TEXT="quote_date: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="A38EBC69-9AE4-4AF4-BFCC-312C051F74EE" TEXT="estimated_delivery: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="13121027-DA33-4545-A40F-8A7F7F1FAE52" TEXT="description: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="ABA3054A-81D6-4A7D-80CA-3E8AD8B94F23" TEXT="place_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
                <arrowlink DESTINATION="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="A85D81EB-584A-43AF-81FA-2651B590221E" TEXT="id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="D5A6D487-28B8-4BA9-8910-B9806568EABA" TEXT="service: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="9F0524E4-ED7D-4860-BEBC-97D73A3AF4E4" TEXT="category: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="0ADED0C8-69FE-4BED-86E4-4A474905B056" TEXT="current_status: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
            <node ID="B199797C-2E5A-40EC-ACBA-2E2EAA36F583" TEXT="name: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="359100A8-1B53-449D-AC17-F969E778B6E6" TEXT="details: text" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="5F88AE76-1B4C-4084-B5B4-49856F9F2278" TEXT="total_nrc: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="D2670D64-FFF2-4F1D-B02E-71EA8FE995B2" TEXT="open_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
                <arrowlink DESTINATION="9B7B9CF4-1A0B-49E3-8538-D8FDFED92BF8" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="6A8201A2-7967-4225-8240-B6153BB73AE1" TEXT="total_mrc: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
            <node ID="11A2DF2F-9DAF-4143-BFF4-FEFAEF80D9F5" TEXT="purchased_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
                <arrowlink DESTINATION="BF151D29-4DCD-4696-AE2E-A0D0CEE60AB9" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="2345289F-E907-461B-87F0-C06537B90BD1" TEXT="valid_until: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="7104F323-0D6E-4C8B-9710-D361DF460049" TEXT="history_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
                <arrowlink DESTINATION="1CC5E402-3DC7-4055-8CC9-0C545F4A71BE" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="53CA6618-4299-4225-81F1-20404C977D65" TEXT="order_status: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="2C6051C1-C9B6-4B7D-A148-CD2C388F8820" TEXT="completion_date:string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
        </node>
        <node ID="C2848F6D-7BF3-40DB-99A2-FDDA29CE3F9E" TEXT="Billing (Info)" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="D25279F2-C735-49EC-8F45-392529F82417" TEXT="comments: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="FC716C20-D264-46EB-9126-AEF35BE825E4" TEXT="invoice_number: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="D2B6E706-49AF-43E9-81B5-41FA211CD6E6" TEXT="id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="649E3E0E-6A9A-4D75-BCBB-5D54594162BC" TEXT="status: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="FDE19126-318D-4CFB-A1DB-4C335CB61BEA" TEXT="invoice_date: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="D996DC0A-589F-4D4E-A912-D22E8A9BA047" TEXT="place_id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
                <arrowlink DESTINATION="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="5926F351-AA99-4B63-9541-A680CF567C60" TEXT="invoice_amount: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
        </node>
        <node ID="6FFA2752-EA2D-412E-9FBC-216B657178D6" TEXT="Products" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="A755D736-B37D-4122-943F-80FAA98EEDA1" TEXT="description: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
            <node ID="032B4B69-A542-408C-B9E7-545E56B7E105" TEXT="id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="9D808AB4-9239-4E77-9BF4-D2D23DD23C24" TEXT="service: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="9B5B3898-AC0F-457A-B2E0-2CD8FCDC3C65" TEXT="mrc_term3: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="0BD2AD45-D508-4DCB-B819-992348BCAE71" TEXT="inservice_date:string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="4A00800E-550F-47E2-90C0-0B1285EFF23A" TEXT="nrc_term2: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="C3E6D234-5A4E-47F5-9DD0-DA01BA6D568C" TEXT="quote_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
                <arrowlink DESTINATION="A85D81EB-584A-43AF-81FA-2651B590221E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="E40DFD54-EFA6-454E-9F75-6B1849FCB3A2" TEXT="nrc_term3: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="FDF35699-8A88-4F1B-BB45-778E11E91F34" TEXT="category: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="8698DB51-3948-48E6-A74A-884E1D7796B5" TEXT="nrc_term1: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="A3E9F0A7-4469-4AE7-983A-E3A8729970A5" TEXT="service_status:string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="67761AEF-B35A-4860-9236-393B6BEB45C9" TEXT="mrc_term2: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="35C96F40-F389-4551-8FAD-38B5426582BC" TEXT="mrc_term1: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="0FD53736-5E1E-43C4-98ED-4024F5705F7E" TEXT="product_catalog_id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
                <arrowlink DESTINATION="023AC9C4-5534-4EB7-9776-AFE241B8DD12" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="76A3FDEF-EC5D-41D0-9869-B458377E2896" TEXT="last_live_date:string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
        </node>
        <node ID="E48599CD-F211-4DC9-BB45-F1B8E1E16CD8" TEXT="(Order) History" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="6D2D63E1-506B-48B6-A38B-6D1FB27A4C05" TEXT="order_nrc: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="01F10B7F-19E7-4AA1-BECE-2F4137D4D6C7" TEXT="order_mrc: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="881E898D-5973-4F8B-A86B-8AA1F3BE8087" TEXT="place_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
                <arrowlink DESTINATION="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="43DF7575-C4E7-4F0B-A95F-98896AB2E3A7" TEXT="service: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="E69B66F7-F2CE-45AB-9E0B-E0B1FFCE879F" TEXT="order_date: datetime" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="7FE30E74-6D01-46BE-AE29-4F9036E7A888" TEXT="details: text" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
            <node ID="1F83B2EE-2244-4AA3-ACDD-EE12E6DC6228" TEXT="order_type: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="87075B3A-38C7-482D-A587-A80FC497F3B7" TEXT="service_type: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="0954C2B5-FA51-486E-A0BC-3BB17D413F63" TEXT="completion_date: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
            <node ID="0F0BE50E-F696-45C0-9033-F8AB84BE7402" TEXT="order_status: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="1CC5E402-3DC7-4055-8CC9-0C545F4A71BE" TEXT="id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
        </node>
        <node ID="D01DADE3-8026-459B-AB98-FE943A628831" TEXT="Open (Quote)" FOLDED="false" COLOR="#000000">
            <font NAME="HelveticaNeue" SIZE="14"></font>
            <edge COLOR="#7F7F7F"></edge>
            <node ID="73CC342A-26B3-4498-88DC-74BFC29E17F2" TEXT="order_mrc: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#D1D500"></edge>
            </node>
            <node ID="565FBE5A-597D-412A-ADA7-DCC48A8A6BFC" TEXT="order_status: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00DA00"></edge>
            </node>
            <node ID="3DC939C8-0035-40F5-BD9E-0928CCB96316" TEXT="quote_date: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="BE585D01-6605-48B8-A2ED-DFC970C7969C" TEXT="valid_until: string" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#00D9AB"></edge>
            </node>
            <node ID="2D1CA60E-6157-4393-BDFD-A369B0E48E07" TEXT="place_id: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
                <arrowlink DESTINATION="80B33320-B306-4E5D-8D4F-5C1C9D796B2E" COLOR="#007FFF" STARTARROW="None" ENDARROW="Default"></arrowlink>
            </node>
            <node ID="9B7B9CF4-1A0B-49E3-8538-D8FDFED92BF8" TEXT="id: integer" POSITION="left" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#7700D9"></edge>
            </node>
            <node ID="261356B2-9077-422D-A1AF-97370EE69C3B" TEXT="quote_name: string" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#009BD7"></edge>
            </node>
            <node ID="34AD6A05-BDF2-4F99-89A4-38ECEBD24369" TEXT="order_nrc: integer" POSITION="right" FOLDED="false" COLOR="#000000">
                <font NAME="HelveticaNeue" SIZE="14"></font>
                <edge COLOR="#E73634"></edge>
            </node>
        </node>
    </node>
</map>