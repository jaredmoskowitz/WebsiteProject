class FixColumnName < ActiveRecord::Migration   #I did not realize that type was a reserved word in rails
  def change
    rename_column :product_catalogs, :type, :category
    rename_column :products, :type, :category
    rename_column :quotes, :type, :category
  end
end
