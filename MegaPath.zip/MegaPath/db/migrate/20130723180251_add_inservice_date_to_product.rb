class AddInserviceDateToProduct < ActiveRecord::Migration
  def change
    add_column :products, :inservice_date, :string
  end
end
