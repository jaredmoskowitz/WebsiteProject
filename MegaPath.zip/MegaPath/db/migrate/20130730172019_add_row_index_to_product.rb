class AddRowIndexToProduct < ActiveRecord::Migration
  def change
    add_column :products, :row_index, :integer
  end
end
