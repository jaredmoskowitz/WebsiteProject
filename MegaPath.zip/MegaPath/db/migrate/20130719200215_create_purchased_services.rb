class CreatePurchasedServices < ActiveRecord::Migration
  def change
    create_table :purchased_services do |t|
      t.string :inservice_date
      t.string :service_type
      t.string :service
      t.string :service_identification
      t.string :service_status
      t.string :last_live
      t.integer :order_mrc
      t.integer :order_nrc
      t.references :place

      t.timestamps
    end
    add_index :purchased_services, :place_id
  end
end
