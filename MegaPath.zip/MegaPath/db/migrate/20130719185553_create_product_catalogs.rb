class CreateProductCatalogs < ActiveRecord::Migration
  def change
    create_table :product_catalogs do |t|
      t.string :product_identification
      t.string :type
      t.string :service
      t.string :description
      t.integer :mrc_term1
      t.integer :mrc_term2
      t.integer :mrc_term3
      t.integer :nrc_term1
      t.integer :nrc_term2
      t.integer :nrc_term3

      t.timestamps
    end
  end
end
