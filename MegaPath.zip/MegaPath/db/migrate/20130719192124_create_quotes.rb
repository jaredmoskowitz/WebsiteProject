class CreateQuotes < ActiveRecord::Migration
  def change
    create_table :quotes do |t|
      t.string :name
      t.string :type
      t.string :service
      t.string :description
      t.string :estimated_delivery
      t.string :current_status
      t.integer :total_mrc
      t.integer :total_nrc
      t.text :details
      t.references :place
      t.references :open_quote
      t.references :order_history
      t.references :purchased_service

      t.timestamps
    end
    add_index :quotes, :place_id
    add_index :quotes, :open_quote_id
    add_index :quotes, :order_history_id
    add_index :quotes, :purchased_service_id
  end
end
