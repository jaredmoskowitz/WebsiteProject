class CreateOrderHistories < ActiveRecord::Migration
  def change
    create_table :order_histories do |t|
      t.datetime :order_date
      t.string :order_type
      t.string :service_type
      t.string :service
      t.string :completion_date
      t.string :order_status
      t.integer :order_mrc
      t.integer :order_nrc
      t.text :details
      t.references :place

      t.timestamps
    end
    add_index :order_histories, :place_id
  end
end
