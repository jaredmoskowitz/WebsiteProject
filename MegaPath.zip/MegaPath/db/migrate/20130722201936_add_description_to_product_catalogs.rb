class AddDescriptionToProductCatalogs < ActiveRecord::Migration
  def change
    add_column :product_catalogs, :description, :string
  end
end
