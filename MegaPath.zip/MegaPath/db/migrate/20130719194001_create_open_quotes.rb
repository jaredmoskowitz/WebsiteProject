class CreateOpenQuotes < ActiveRecord::Migration
  def change
    create_table :open_quotes do |t|
      t.string :quote_date
      t.string :quote_name
      t.string :valid_until
      t.string :quote_status
      t.integer :order_mrc
      t.integer :order_nrc
      t.references :place

      t.timestamps
    end
    add_index :open_quotes, :place_id
  end
end
