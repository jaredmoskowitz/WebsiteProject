class AddCompletionDateToQuote < ActiveRecord::Migration
  def change
    add_column :quotes, :completion_date, :string
  end
end
