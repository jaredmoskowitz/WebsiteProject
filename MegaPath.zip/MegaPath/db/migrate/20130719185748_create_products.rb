class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.string :product_identification
      t.string :type
      t.string :service
      t.string :description
      t.string :mrc_term1
      t.string :mrc_term2
      t.string :mrc_term3
      t.string :nrc_term1
      t.string :nrc_term2
      t.string :nrc_term3
      t.references :product_catalog
      t.references :quote

      t.timestamps
    end
    add_index :products, :product_catalog_id
    add_index :products, :quote_id
  end
end
