class CreateServices < ActiveRecord::Migration
  def change
    create_table :services do |t|
      t.string :name
      t.string :CLLI
      t.string :address
      t.float :longitude
      t.float :latitude
      t.boolean :gmaps
      t.string :BSDL
      t.string :EoCu
      t.string :EoDS1
      t.string :EoDMT

      t.timestamps
    end
  end
end
