class AddOrderStatusToQuote < ActiveRecord::Migration
  def change
    add_column :quotes, :order_status, :string
  end
end
