class AddOrderTypeToQuote < ActiveRecord::Migration
  def change
    add_column :quotes, :order_type, :string
  end
end
