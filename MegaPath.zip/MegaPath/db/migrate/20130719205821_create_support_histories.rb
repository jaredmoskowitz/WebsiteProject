class CreateSupportHistories < ActiveRecord::Migration
  def change
    create_table :support_histories do |t|
      t.string :reported_on
      t.string :service_type
      t.string :service
      t.string :service_identification
      t.string :ticket_status
      t.string :description
      t.string :last_status_date
      t.references :place

      t.timestamps
    end
    add_index :support_histories, :place_id
  end
end
