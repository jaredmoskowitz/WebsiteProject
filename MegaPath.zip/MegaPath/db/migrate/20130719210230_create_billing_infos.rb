class CreateBillingInfos < ActiveRecord::Migration
  def change
    create_table :billing_infos do |t|
      t.string :invoice_date
      t.string :status
      t.string :invoice_number
      t.string :comments
      t.integer :invoice_amount
      t.references :place

      t.timestamps
    end
    add_index :billing_infos, :place_id
  end
end
