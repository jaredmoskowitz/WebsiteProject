class AddServiceStatusToProduct < ActiveRecord::Migration
  def change
    add_column :products, :service_status, :string
  end
end
