class CreatePlaces < ActiveRecord::Migration
  def change
    create_table :places do |t|
      t.string :name
      t.string :address
      t.string :status
      t.string :phone_number
      t.string :email_address
      t.float :longitude
      t.float :latitude
      t.boolean :gmaps
      t.boolean :validated, :default => false
      t.references :user

      t.timestamps
    end
    add_index :places, :user_id
  end
end
