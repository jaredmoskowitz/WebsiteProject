class AddQuoteDateToQuote < ActiveRecord::Migration
  def change
    add_column :quotes, :quote_date, :string
  end
end
