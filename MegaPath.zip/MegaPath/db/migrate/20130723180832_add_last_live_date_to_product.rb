class AddLastLiveDateToProduct < ActiveRecord::Migration
  def change
    add_column :products, :last_live_date, :string
  end
end
