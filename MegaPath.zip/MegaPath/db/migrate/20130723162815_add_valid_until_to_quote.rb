class AddValidUntilToQuote < ActiveRecord::Migration
  def change
    add_column :quotes, :valid_until, :string
  end
end
