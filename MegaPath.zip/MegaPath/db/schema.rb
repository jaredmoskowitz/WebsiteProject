# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20130730172019) do

  create_table "billing_infos", force: true do |t|
    t.string   "invoice_date"
    t.string   "status"
    t.string   "invoice_number"
    t.string   "comments"
    t.integer  "invoice_amount"
    t.integer  "place_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "billing_infos", ["place_id"], name: "index_billing_infos_on_place_id"

  create_table "characters", force: true do |t|
    t.string   "name"
    t.string   "address"
    t.float    "longitude"
    t.float    "latitude"
    t.boolean  "gmaps"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "locations", force: true do |t|
    t.string   "address"
    t.float    "latitude"
    t.float    "longitude"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "open_quotes", force: true do |t|
    t.string   "quote_date"
    t.string   "quote_name"
    t.string   "valid_until"
    t.string   "quote_status"
    t.integer  "order_mrc"
    t.integer  "order_nrc"
    t.integer  "place_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "open_quotes", ["place_id"], name: "index_open_quotes_on_place_id"

  create_table "order_histories", force: true do |t|
    t.datetime "order_date"
    t.string   "order_type"
    t.string   "service_type"
    t.string   "service"
    t.string   "completion_date"
    t.string   "order_status"
    t.integer  "order_mrc"
    t.integer  "order_nrc"
    t.text     "details"
    t.integer  "place_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "order_histories", ["place_id"], name: "index_order_histories_on_place_id"

  create_table "places", force: true do |t|
    t.string   "name"
    t.string   "address"
    t.string   "status"
    t.string   "phone_number"
    t.string   "email_address"
    t.float    "longitude"
    t.float    "latitude"
    t.boolean  "gmaps"
    t.boolean  "validated",     default: false
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "places", ["user_id"], name: "index_places_on_user_id"

  create_table "product_catalogs", force: true do |t|
    t.string   "product_identification"
    t.string   "category"
    t.string   "service"
    t.integer  "mrc_term1"
    t.integer  "mrc_term2"
    t.integer  "mrc_term3"
    t.integer  "nrc_term1"
    t.integer  "nrc_term2"
    t.integer  "nrc_term3"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "description"
  end

  create_table "products", force: true do |t|
    t.string   "product_identification"
    t.string   "category"
    t.string   "service"
    t.string   "mrc_term1"
    t.string   "mrc_term2"
    t.string   "mrc_term3"
    t.string   "nrc_term1"
    t.string   "nrc_term2"
    t.string   "nrc_term3"
    t.integer  "product_catalog_id"
    t.integer  "quote_id"
    t.integer  "place_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "description"
    t.string   "inservice_date"
    t.string   "service_status"
    t.string   "last_live_date"
    t.integer  "row_index"
  end

  add_index "products", ["place_id"], name: "index_products_on_place_id"
  add_index "products", ["product_catalog_id"], name: "index_products_on_product_catalog_id"
  add_index "products", ["quote_id"], name: "index_products_on_quote_id"

  create_table "purchased_services", force: true do |t|
    t.string   "inservice_date"
    t.string   "service_type"
    t.string   "service"
    t.string   "service_identification"
    t.string   "service_status"
    t.string   "last_live"
    t.integer  "order_mrc"
    t.integer  "order_nrc"
    t.integer  "place_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "purchased_services", ["place_id"], name: "index_purchased_services_on_place_id"

  create_table "quotes", force: true do |t|
    t.string   "name"
    t.string   "category"
    t.string   "service"
    t.string   "description"
    t.string   "estimated_delivery"
    t.string   "current_status"
    t.integer  "total_mrc"
    t.integer  "total_nrc"
    t.text     "details"
    t.integer  "place_id"
    t.integer  "open_quote_id"
    t.integer  "order_history_id"
    t.integer  "purchased_service_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "quote_date"
    t.string   "valid_until"
    t.string   "order_type"
    t.string   "completion_date"
    t.string   "order_status"
  end

  add_index "quotes", ["open_quote_id"], name: "index_quotes_on_open_quote_id"
  add_index "quotes", ["order_history_id"], name: "index_quotes_on_order_history_id"
  add_index "quotes", ["place_id"], name: "index_quotes_on_place_id"
  add_index "quotes", ["purchased_service_id"], name: "index_quotes_on_purchased_service_id"

  create_table "s_products", force: true do |t|
    t.string   "service"
    t.string   "type"
    t.integer  "mrc_term1"
    t.integer  "mrc_term2"
    t.integer  "mrc_term3"
    t.integer  "nrc_term1"
    t.integer  "nrc_term2"
    t.integer  "nrc_term3"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "services", force: true do |t|
    t.string   "name"
    t.string   "CLLI"
    t.string   "address"
    t.float    "longitude"
    t.float    "latitude"
    t.boolean  "gmaps"
    t.string   "BSDL"
    t.string   "EoCu"
    t.string   "EoDS1"
    t.string   "EoDMT"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "support_histories", force: true do |t|
    t.string   "reported_on"
    t.string   "service_type"
    t.string   "service"
    t.string   "service_identification"
    t.string   "ticket_status"
    t.string   "description"
    t.string   "last_status_date"
    t.integer  "place_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "support_histories", ["place_id"], name: "index_support_histories_on_place_id"

  create_table "users", force: true do |t|
    t.string   "email",                              default: "", null: false
    t.string   "encrypted_password",     limit: 128, default: "", null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",                      default: 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.string   "title"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "users", ["email"], name: "index_users_on_email", unique: true
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true

end
