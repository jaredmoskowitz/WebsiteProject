MegaPath::Application.routes.draw do
  get '/mega' => 'mega#index', :as => 'mega'  #mega_path!!!!!!!!!!!!!!!!!

  resources :billing_infos

  resources :support_histories

  resources :purchased_services

  resources :order_histories
  get 'order_histories/data(/:id)(.:format)' => 'order_histories#data'

  post 'open_quotes/:id(.:format)' => 'open_quotes#show'
  resources :open_quotes


  post 'quotes/:id(.:format)' => 'quotes#show'
  post 'quotes(/:id)(.:format)' => 'quotes#create'
  resources :quotes




  resources :products do
    put 'add(/:quote_id)(/:service_id)(.:format)' => 'products#add', on: :collection
    delete 'delete(/:quote_id)(/:service_id)(.:format)' => 'products#delete', on: :collection
  end

  get 'product_catalogs/access' => 'product_catalogs#access'
  get 'product_catalogs/bundles' => 'product_catalogs#bundles'
  get 'product_catalogs/voice' => 'product_catalogs#voice'
  get 'product_catalogs/security' => 'product_catalogs#security'
  resources :product_catalogs


  devise_for :users do get '/users/sign_out' => 'devise/sessions#destroy' end

  resources :places do
    collection{post :import}
    put :createUser, :on => :collection
  end


  get 'places/signed_in'
  get 'places/user_current'

  get 'emailpassword' => 'places#email_password', :as => 'email_password'

  resources :page
  post 'page/home'
  get 'page/home'

  root :to => 'page#index'
end
