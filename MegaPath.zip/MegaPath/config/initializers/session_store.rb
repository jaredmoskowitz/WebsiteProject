# Be sure to restart your server when you modify this file.

MegaPath::Application.config.session_store :cookie_store, key: '_MegaPath_session'
