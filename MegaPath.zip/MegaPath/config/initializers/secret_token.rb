# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
MegaPath::Application.config.secret_key_base = '5967c8f8f5d24b2ae4a86d25b6e1dae0606c190b5bd29b6dabeb2a933dfa6294fc928a310be5cbab16996b4e79c5ea4ec5709cacdbbe8fcc48dd1b83bb5bd08d'
